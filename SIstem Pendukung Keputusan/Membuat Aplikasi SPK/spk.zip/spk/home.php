<div class="container my-4">
    <div class="jumbotron">
      <h1 class="text-center">Selamat Datang Di Sistem Pendukung Keputusan</h1>
      <h1 class="text-center">Guru Terbaik</h1>
      <hr class="my-4">
      <p class="lead text-center">
        Ini adalah Sistem Pendukung Keputusan "Guru Terbaik" Berbasis Website dengan metode SAW
      </p> 
    </div>
</div>
